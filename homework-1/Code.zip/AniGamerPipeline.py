from elk import elk

class AniGamerPipeline:
    def process_item(self, item, spider):
        elk.index(index='danmu', body={
            'color': item['color'],
            'position': item['position'],
            'size': item['size'],
            'sn': item['sn'],
            'text': item['text'],
            'time': item['time'],
            'userid': item['userid'],
        })
        return item